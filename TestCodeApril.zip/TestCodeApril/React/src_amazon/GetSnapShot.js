import { Component } from "react";

class GetDerivedState extends Component
{
    constructor(props)
    {
        super(props);
        this.state={f_Color:'red'};
    }

    componentDidMount()
    {
        setTimeout(() => {
            this.setState({f_Color:'yellow'})
        }, 5000)
    }

    getSnapshotBeforeUpdate(prevProps, prevState)
    {
        document.getElementById("div1").innerHTML = "Before the update, the favorite color was" +
        prevState.f_Color;
    }

    componentDidUpdate()
    {
        document.getElementById("div2").innerHTML = "the udpated favorite color is: " +
        this.state.f_Color; 
    }

    render() {
        return(
            <>
            <h1>Favorite color is {this.state.f_Color}</h1>
            <div id="div1"></div>
            <div id="div2"></div>
            </>
        );
    }
}

export default GetDerivedState;