import logo from './logo.svg';
import { useState } from 'react';
import Product from './Product';
import Jsx from './JSXDemo';
import Constructor_demo from './ConstructorDemo';
import GetDerived from './GetDerived';
import Component_Did_Mount from './ComponentDidMount';
import ShouldComponentUpdate from './ShouldComponentUpdate';
import GetDerivedState from './GetSnapShot';
import ComponentWillMount from './ComponentWillUnMount';
import Car from './CarProps';
import Pass_Data from './PassData';
import PropsDemo from './PropsDemo';
import Person from './Person';
import Counter from './Counter';
import Employee from './EmployeeState';
import ConditionalRender from './ConditionalRender';
import ListDemo from './ListDemo';
import FormDemo from './FormDemo';
import ProductForm from './ProductForm';
import BootstrapDemo from './BootstrapDemo';
import Bootstrap1 from './Bootstrap1';
import UseState from './UseState';
import UseState2 from './UseState2';
import UseEffect from './UseEffect';
import UseEffect2 from './UseEffect2';
import EmpList from './EmpList';
import ProductList from './ProductList';
import EmployeeHook from './EmployeeHook';
import WithoutUseContext from './WithoutUseContext';
import UseContext from './UseContext';
import UseRefDemo from './UseRefDemo';
import UseReducerDemo from './UseReducer';

import './App.css';

function App() {
  const fruits = ["apple", "orange", "grape", "mango", "banana"];
  const [data, setData] = useState([]);
  const [value, setValue] = useState('');

  const handleAdd = () => {
    setData([...data, Number(value)])
    setValue('');
  }

  return (
    <div className="App">
      {/* <hr/>
      <Product/>
      <Jsx />
      <hr/>
      <Constructor_demo/>
      <hr/>
      <GetDerived fcolor="red"/>
      <hr />
      <Component_Did_Mount/>
      <hr />
      <ShouldComponentUpdate/>
      <hr/>
      <GetDerivedState/>
      <hr/>
      <br/>
      <ComponentWillMount/>
      <hr/>
      <Car brand="Audi" />
      <hr/> 
      <br/>
      <Pass_Data />
      <PropsDemo title="My Title" description="My Description" items={fruits}/>
      <Person name="Alice" age="27" occupation="Software Engineer"/>
      <Person name="George" age="30" occupation="Production Manager"/>
      <Counter/>
      <Employee empid="10011" empname="Jackson" department="Development" />
      <ConditionalRender />
      <ListDemo/>
      <FormDemo />
      <ProductForm/>
      <Bootstrap1/>
      <UseState2/>
      <UseEffect2/>
      <EmpList/>
      <ProductList/>
      <EmployeeHook/>
      <WithoutUseContext/>
      <UseContext/>
      <UseRefDemo/>
      <UseReducerDemo/>
      <input type="text" value={value} onChange={ e => setValue(e.target.value)}/>
      <button onClick={handleAdd}>Add</button>
      <p>Total: {total}</p>*/}
      
    </div>
  );
}

export default App;
