function Employee()
{
    return(
        <>
        <h1>Employee Form</h1>
        <form>
            <label>Name: <input></input></label><br></br>
            <label>Id:<input></input> </label><br></br>
            <label>DOB: <input></input></label><br></br>
            <label>Company: <input></input></label>
        </form>
        </>
    );
}

export default Employee;