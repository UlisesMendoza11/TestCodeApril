import { Component } from "react";
import styles from './my-style.css';

class Employee extends Component
{
    constructor(props)
    {
        super(props);
        this.state={
            empid:props.empid,
            name:props.name,
            department:props.department
        };

        this.changeEmpId = this.changeEmpId.bind(this);
        this.changeEmpName = this.changeEmpName.bind(this);
        this.changeDepartment = this.changeDepartment.bind(this);
    }

    changeEmpId(event) { this.setState({empid:event.target.value}) }
    changeEmpName(event) { this.setState({empname:event.target.value}) }
    changeDepartment(event) { this.setState({department:event.target.value}) }

    render(){
        return(
            <div className="cls2">
                EmpId:<input type="text" value={this.state.empid} onChange={this.changeEmpId}></input><br/>
                EmpName:<input type="text" value={this.state.empname}onChange={this.changeEmpName} ></input><br/>
                Department:<input type="text" value={this.state.department} onChange={this.changeDepartment}></input>
            </div>
        )
    }
}

export default Employee;