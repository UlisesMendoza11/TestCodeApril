import { Component } from "react";

class ComponentWillMount extends Component
{
    constructor(props)
    {
        super(props);
        this.state={show: true};
    }

    delHeader = () => {
        this.setState({show: false});
    }

    render() {
        let myHeader;
        if(this.state.show)
        {
            myHeader=<Child />
        };
        return(
            <>
            {myHeader}
            <button type="button" onClick={this.delHeader}>Delete Header Component</button>
            </>
        );
    }
}

class Child extends Component
{
    componentWillUnmount()
    {
        alert("The component named Header is about to unmount...")
    }
    render() {
        return(
            <h1>Hello World from Child Component</h1>
        )
    }
}

export default ComponentWillMount;