import {useRef} from 'react';

function UseRefDemo() {
    const inputRef = useRef(null);

    function handleClick()
    {
        inputRef.current.focus();
    }

    return(
        <>
        <input type="text" ref={inputRef}/>
        <button onClick={handleClick}>Focus Input</button>
        </>
    );
}

export default UseRefDemo;