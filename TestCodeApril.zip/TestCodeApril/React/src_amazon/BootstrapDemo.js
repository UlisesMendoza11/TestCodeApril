import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';

function BootstrapDemo() {
  return (
    <div className="container">
      <h1 className="text-center mt-5">React Demo using Bootstrap</h1>
      <div className="row mt-5">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">Card Title</div>
            <div className="card-body">
              <p className="card-text">This is some text within a card body.</p>
            </div>
          </div>
        </div>
            from Project Management to everyone:    2:29 PM
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">Card Title</div>
            <div className="card-body">
              <p className="card-text">This is some text within a card body.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BootstrapDemo;