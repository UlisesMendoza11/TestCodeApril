function Person(props)
{
    return(
        <div>
            <h2>{props.name}</h2>
            <h2>{props.age}</h2>
            <p>Occupation:{props.occupation}</p>
        </div>
    )
}

export default Person;