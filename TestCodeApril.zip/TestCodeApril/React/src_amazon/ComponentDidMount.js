import { Component } from "react";

class Component_Did_Mount extends Component
{
    constructor(props)
    {
        super(props)
        {
            this.state = {fav_color: 'red'};
        }
    }

    componentDidMount()
    {
        setTimeout(() => {
            this.setState({fav_color: "yellow"})
        }, 5000)
    }

    render() {

        return(
            <>
            <h1>My Favorite color is {this.state.fav_color}</h1>
            </>
        );
    }
}

export default Component_Did_Mount;