import React, { useState } from 'react';
import styles from './my-style.css';

function ProductForm()
{
    const [productData, setProductData] = useState({
        name: '',
        price: '',
        description: '',
        image: ''
    })

    const handleChange = (event) => {
        const {name, value} = event.target;
        setProductData({...productData, [name]:value });
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(productData);
    };

    return(
        <div>
            <h1>Product Form</h1>
            <form onSubmit={handleSubmit} className="cls">
                <label htmlFor="name">
                    ProductName:
                    <input type="text" name="name" id="name" value={productData.name} onChange={handleChange} />
                </label>
                <br/><br/>
                <label htmlFor="price">
                    Price:
                    <input type="number" name="price" id="price" value={productData.price} onChange={handleChange} />
                </label>
                <br/><br/>
                <label htmlFor="description">
                    Description:
                    <textarea type="description" name="description" id="description" value={productData.description} onChange={handleChange} />
                </label>
                <br/><br/>
                <label htmlFor="image">
                    Image Url:
                    <input type="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMc6nQEdScA34FQ-jYPVw17RO_QRwzqPLOCg&usqp=CAU" name="image" id="image" value={productData.image} onChange={handleChange} />
                </label>
                <br/><br/>
                <button type="submit">Add Product</button>
            </form>
        </div>
    );
}

export default ProductForm;