import { Component } from "react";

class Get_Derived_State extends Component
{
    constructor(props)
    {
        super(props)
        this.state={fav_Color: 'red'};
    }

    static getDerivedStateFromProps(props, state)
    {
        return {fav_Color:props.fcolor};
    }

    render(){
        return(
            <>
            <h1>My Favorite Color is {this.state.fav_Color}</h1>
            </>
        );
    }
}

export default Get_Derived_State;