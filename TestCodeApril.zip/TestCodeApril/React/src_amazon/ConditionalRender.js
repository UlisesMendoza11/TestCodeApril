import { Component } from "react";
import styles from './my-style.css';

class ConditionalRender extends Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            isLoggedIn: false
        };
        this.handleLogin = this.handleLogin.bind(this);
        this.handleLogOut = this.handleLogOut.bind(this);
    }

    handleLogin(){ this.setState({isLoggedIn: true}); }
    handleLogOut(){ this.setState({isLoggedIn: false}); }
    render(){
        const isLoggedIn = this.state.isLoggedIn;
        // const myStyle = {
        //     color: "red",
        //     backgroundColor: 'pink'
        // }
        return(
            <div>
                {isLoggedIn ? (
                    <div className="cls">
                        <h1 style={styles}>Welcome, User!...</h1>
                        <button onClick={this.handleLogOut}>Logout</button>    
                    </div>
                ) : (<div className="cls">
                        <h1 style={styles}>Please Login.</h1>
                        <button onClick={this.handleLogin}>Logout</button>
                    </div>
                )}
            </div>
        );
    }
}

export default ConditionalRender;