import React, { useState } from 'react';

function FormDemo()
{
    const [name, setName] = useState('Name1');
    const [email, setEmail] = useState('name@gmail.com');

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log('Name:', name);
        console.log('Email:', email);
    };

    return(
        <div>
            <h1>Form Demo</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    Name:
                    <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
                </label>
                <br/><br/>
                <label>
                    Email:
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </label>
                <br/><br/>
                <button type="Submit">Submit</button>
            </form>
        </div>
    );
}

export default FormDemo;