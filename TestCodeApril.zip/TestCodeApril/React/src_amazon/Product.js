
function Product()
{
    return(
        <>
        <h1>Product Component</h1>
        <table border='2'>
            <thead>
                <th>ID</th>
                <th>Name</th>
                <th>Price</th>
            </thead>
            <tbody>
                <tr><td>10011</td><td>Books</td><td>5000</td></tr>
                <tr><td>10022</td><td>Stationary</td><td>20000</td></tr>
                <tr><td>10033</td><td>Table</td><td>35000</td></tr>
                <tr><td>10044</td><td>Chair</td><td>55000</td></tr>
                <tr><td>10011</td><td>Books</td><td>100000</td></tr>
                {/* <tr>
                    <img src=""></img>
                </tr> */}
            </tbody>
        </table>
        </>
    );
}

export default Product;