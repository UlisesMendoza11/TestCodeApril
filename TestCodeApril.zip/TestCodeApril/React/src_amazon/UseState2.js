import React, {useState} from 'react';

function UseState2()
{

    const [count, setCount] = useState(0);
    const [text, setText] = useState("");

    const handleCountClick = () => {
        setCount(count+1);
    };

    const handleTextChange = (event) => {
        setText(event.target.value);
    };

    return(
        <>
        <h1>Count : {count}</h1>
        <button onClick={handleCountClick}>Increment</button>
        <hr/>
        <h1>Text: {text}</h1>
        <input type="text" value={text} onChange={handleTextChange}/>
        </>
    );
}

export default UseState2;