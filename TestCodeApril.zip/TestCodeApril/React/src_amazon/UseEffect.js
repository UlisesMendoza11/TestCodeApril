import {useState, useEffect} from 'react';

function UseEffect() {
    const [count, setCount] = useState(0);

    useEffect(() => {
        document.title = 'Count : ${count}';
    }, [count]);

    const handleCountClick = () => {
        setCount(count+1);
    };

    return (
        <>
        <p>Count: {count}</p>
        <button onClick={handleCountClick}>Increment</button>
        </>
    );
}

export default UseEffect;