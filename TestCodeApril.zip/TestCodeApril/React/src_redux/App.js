import logo from './logo.svg';
import CoursePage from './CoursePage';
import './App.css';

function App() {
  return (
    <div className="App">
      <CoursePage/>
    </div>
  );
}

export default App;
