
function GmailButton()
{
    return(
        <button className="gmailButton" type="button">Next</button>
    );
}

export default GmailButton;