import React, { useState } from 'react';
import GmailHeader from './GmailHeader';
import Gmail_Input from './Gmail_Input';
import GmailButton from './GmailButton';
import styles from './GmailStyle.css';

function GmailForm()
{
    const [email, setEmail] = useState('');

    // const handleSubmit = (event) => {
    //     event.preventDefault();
    //     console.log('Name:', name);
    //     console.log('Email:', email);
    // };

    return(
        <div>
            <form className="gmailForm">
                <GmailHeader/>
                <div>
                    <Gmail_Input/>
                    <a href="#" className="gmailLink1">Forgot email?</a>
                    <p className="gmailPara">Not your computer? Use a private browsing window to sign in.
                        <a href="#" className="gmailLink2"> Learn more</a>
                    </p>
                    <br/>
                    <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                        <div className="spanDiv">
                            <span className="gmailLink3">Create account</span>
                        </div>
                        <GmailButton/>
                    </div>
                </div>
            </form>
        </div>
    );
}

export default GmailForm;