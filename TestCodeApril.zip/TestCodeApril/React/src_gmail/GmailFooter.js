import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';

function GmailFooter()
{
    return(
        <div style={{display: 'flex', justifyContent: 'space-between', paddingTop: '10px', width: '100%', alignItems: 'center'}}>
            {/* <div className="container">
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle"
                    type="button" data-toggle="dropdown">English (United States)
                    <span class="caret"></span></button>
                    <ul class="dropdown-menu dropdown-menu-right">
                        <li><a href="./Buttons.html">Buttons Demo</a></li>
                        <li><a href="./Panel.html">Panel Demo</a></li>
                        <li><a href="./Images.html">Images Demo</a></li>
                    </ul>
                </div>
            </div> */}
            <div>
                <a href="#" className="footerLinks">Help</a>
                <a href="#" className="footerLinks">Privacy</a>
                <a href="#" className="footerLinks">Terms</a>
            </div>
        </div>
    );
}

export default GmailFooter;