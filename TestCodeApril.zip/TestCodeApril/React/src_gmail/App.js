import logo from './logo.svg';
import './App.css';
import GmailForm from './GmailForm';
import GmailFooter from './GmailFooter';

function App() {
  return (
    <div className="App">
      <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
        <GmailForm/>
        {/* <GmailFooter/> */}
      </div>
    </div>
  );
}

export default App;
