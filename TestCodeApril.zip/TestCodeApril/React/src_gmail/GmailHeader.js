
function GmailHeader()
{
    return(
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
            <img src="https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png"
            style={{height: '28px', width: "80px", marginBottom: '10px'}}></img>
            <h1 className="gmailHeader1">Sign in</h1>
            <h2 className="gmailHeader2">to continue to Gmail</h2>
        </div>
       
    );
}

export default GmailHeader;