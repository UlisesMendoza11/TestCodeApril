
function Gmail_Input()
{
    return(
        <>
        <input className="gmail_Input" type="text" placeholder="Email or phone"></input>
        </>
    );
}

export default Gmail_Input;