import {EventEmitter} from 'events';
import Dispatcher from "../Dispatcher/Dispatcher";

class AuthorStore extends EventEmitter
{
    constructor()
    {
        super();
        this.author=[
            {authorName:'Sachin'},{authorName:"Sevak"}
        ]
    }
    createAuthor(authorName)
    {
        this.authors.push({authorName});
        this.emit("change");
    }

    getAllAuthors()
    {
        return this.authors;
    }

    handleActions(action)
    {
        switch(action.type)
        {
            case "CREATE_AUTHOR": {
                this.createAuthor(action.authroName);
                break;
            }
        }
    }
}

const authorStore = new AuthorStore();
Dispatcher.register(authorStore.handleActions.bind(authorStore));
export default authorStore;
