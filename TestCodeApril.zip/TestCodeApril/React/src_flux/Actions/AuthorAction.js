/**
 * Flux architecture is a software design pattern that was developed by Facebook for building 
 * user interfaces. It is based on the concept of unidirectional data flow, where the data flows 
 * in a single direction through the application, from the action of the user to the view that 
 * is displayed on the screen.

The Flux architecture consists of four main components:

View: The user interface that the user interacts with.

Action: An action that the user initiates, such as clicking a button or typing into a 
text field.

Dispatcher: A central hub that receives actions and dispatches them to the appropriate 
stores.

Store: A store contains the application's state and logic for updating that state in 
response to actions.
One of the key benefits of the Flux architecture is that it makes it easier to reason 
about how data flows through the application, since there is a clear separation of 
concerns between the different components. It also makes it easier to maintain and 
modify the application, since changes to the state a


    Flux is a type of architecture used in react that is based on the concept of data
    flowing in one direction. Made up of 4 components: action, dispatcher, store, and view.
    Action initiated by user, dispatcher sends to proper store, store uses logic to update,
    and view changes accordingly.

    Redux is similar to flux, but where it is different is that instead of dispatcher you have
    a reducer. When an action is performed by user, actions are sent to reducer to update the
    state that is stored in the store rather than the store updating the view in flux.
    
 * 
 *
 * React Redux is a popular library for managing the state of React applications. 
 * It provides a predictable and centralized way to store, access, and 
 * update application state, which can help make applications more scalable, 
 * maintainable, and performant.
 * 
 * Redux works by storing the application state in a single object called 
 * the "store", and providing a set of methods to read and update this state. React 
 * components can then access the store and dispatch actions, which are plain JavaScript
 * objects that describe what changes should be made to the state. The Redux library 
 * then uses these actions to update the store, triggering a re-rendering of any components 
 * that depend on the updated state.
 * 
 * React Redux is a binding library that connects Redux to React applications, 
 * allowing components to easily access the store and dispatch actions. It provides 
 * a set of helper functions and components, such as "connect" and "Provider", that 
 * simplify the process of integrating Redux with React.
 * 
 * Overall, React Redux can be a power
 */

import Dispatcher from "./Dispatcher/Dispatcher";
export function createAuthor(authorName)
{
    Dispatcher.dispatch({
        type: "CREATE_AUTHOR",
        authorName
    });
}