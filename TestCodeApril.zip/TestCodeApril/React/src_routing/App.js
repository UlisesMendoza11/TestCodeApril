import './App.css';
import {BrowserRouter as Router, Route, Link, Routes} from 'react-router-dom';
import Home from './Home';
import About from './About';
import Contact from './Contact';
import Error from './Error';
import Layout from './Layout';
import React from 'react';
 import axios from 'axios';


const API_URL = 'https://jsonplaceholder.typicode.com';

// function App() {
//   return (
//     <Router>
//       <Routes>
//         <Route path='/' element={<Layout/>}>
//           <Route index element={<Home/>}/>
//           <Route path='about' element={<About/>}/>
//           <Route path='contact' element={<Contact/>}/>
//           <Route path='*' element={<Error/>}/>
//         </Route>
//       </Routes>
//     </Router>
//   );
// }

// export default App;

class App extends React.Component {
  state={
    users:[]
  }
  componentDidMount()
  {
    const url=`${API_URL}/users/`;
    axios.get(url)
      .then(response=>response.data)
      .then((data) => {
        this.setState({users:data})
        console.log(this.state.users)
      }, [])
  }

  render(){
    return(
      <div>
        <h1>React axios Demo</h1>
        <div className='row'>
          <table className='table table-striped table-bordered'>
            <thead>
              <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>UserName</th>
                <th>Website</th>
              </tr>
            </thead>
            <tbody>
              {
                this.state.users.map(
                  user =>
                  <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>{user.username}</td>
                    <td>{user.website}</td>
                  </tr>
                )
              }
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default App;