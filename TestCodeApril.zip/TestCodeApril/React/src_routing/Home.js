import {Link} from 'react-router-dom';

const Home = () => {
    return(
        <>
        <h1>Welcome to the Home Page</h1>
        {/* <p>Click on the links below to navigate to other pages</p>
        <ul>
            <li>
                <Link to="/about">About</Link>
            </li>
            <li>
                <Link to="/contact">Contact</Link>
            </li>
        </ul> */}
        </>
    )
}

export default Home;