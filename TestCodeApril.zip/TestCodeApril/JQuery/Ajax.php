<?php
if($_POST['name'])
{
    echo 'Hello, World'.$_POST('name').'!';
}