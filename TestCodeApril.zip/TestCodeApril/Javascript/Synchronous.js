function slowTask()
{
    
    var now = new Date().getTime();
    while(new Date().getTime<now+5000)
    {

    }
    console.log("slow task done");
}

function fastTask()
{
    console.log("fast Task");
}

fastTask();slowTask();fastTask();slowTask();