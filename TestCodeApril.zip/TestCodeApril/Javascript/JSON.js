// JSON - Java Script Object Notation

const Person = {
    name: 'Sachin',
    age: 30,
    hobbies: ['reading', 'cricket', 'music'],
    address: {
        street: 'xxxxxx street1',
        city: 'xxxxx city1',
        state: 'xxxx state1'
    },
    sayHello:function(){
        console.log(`hello ..${this.name}`)
    }
}

console.log(Person.name);
console.log(Person.hobbies[1]);
console.log(Person.address.city);
console.log(Person.sayHello());