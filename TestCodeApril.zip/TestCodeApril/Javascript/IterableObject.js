var days = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];

for(const d of days)
{
    console.log(d);
}