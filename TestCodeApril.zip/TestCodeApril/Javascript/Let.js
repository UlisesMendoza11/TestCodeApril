let pan_no = "GKTAD9834K";
console.log("Permanent Account Number is: " + pan_no);
// var pan_no = GKTAD9834K;
// console.log("Permanent Account Number is: " + pan_no);
// duplicate is allowed

pan_no = "HJKK57223H";
console.log("Permanent Account Number is: " + pan_no);

{
    let pan_no = "WERD78669G"
    console.log("Inside the block Permanent Account Number is: " + pan_no);
}

console.log("Outside the block Permanent Account Number is: " + pan_no);
