var acc_bal = 15000;

var withdraw_amt = 5000;

if(acc_bal >= withdraw_amt) {
    console.log("Transaction is Successful ... Available Balance is: " + aval_bal);
    var aval_bal = acc_bal - withdraw_amt;
} else {
    console.log("Insufficient Fund .... Available Balance is: " + acc_bal);
}