function outerFunction() {
    const outerVariable = ' i am from the other function ';

    function innerFunction() {
        console.log(outerVariable);
    }
    return innerFunction;
}

const innerFun = outerFunction();
innerFun();
