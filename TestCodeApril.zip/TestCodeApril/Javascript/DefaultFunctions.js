function greet(name='Kalam') {
    console.log(`Hello, ${name}`);
}

greet();

greet('Sachin')
