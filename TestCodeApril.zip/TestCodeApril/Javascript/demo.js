var n1, n2, add;
n1 = 45; n2 = 56;
add = n1 + n2;
console.log("Addition of " + n1 + " and " + n2 + " = " + add);