class Person
{
    constructor(name,age,city)
    {
        this.name=name;
        this.age=age;
        this.city=city;
    }

    display()
    {
        console.log("Name: " + this.name);
    }

}

var p = new Person("Rosey", 22, "Chicago"); p.display();
var p1 = new Person("Madhan", 25, "Los Angeles"); p1.display();