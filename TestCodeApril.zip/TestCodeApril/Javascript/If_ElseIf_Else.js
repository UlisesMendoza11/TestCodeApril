const readLine = require('readline');

const r1 = readLine.createInterface({input:process.stdin, output:process.stdout});

r1.question('Enter the Account Type?', (acc_type)=>{})
var acc_type = "Savings";

if(acc_type == "Savings") {
    console.log("Its Saving Account");
} else if (acc_type == "Current") {
    console.log("Its Current Account");
} else if (acc_type == "Joined") {
    console.log("Its Joined Account");
} else {
    console.log("Invalid Account");
}