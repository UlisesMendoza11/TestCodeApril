const numbers = [10, 23, 34, 54, 23, 54];
const colors = ['red', 'green', 'blue'];
const person = ['John', 30, 'Development'];

const matrix = [[1,2,3],[4,5,6],[7,8,9]];

const emptyArray = [];

console.log(numbers[0]);
console.log(colors[2]);
console.log(person[1]);
console.log(matrix[1][2]);

numbers[2] = 550;
console.log(numbers);
console.log(numbers.length);