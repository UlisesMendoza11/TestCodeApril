// function armStrong() {
//     for(var i = 1; i < 10; ++i) {
//         for(var j = 0; j < 10; ++j) {
//             for(var k = 0; k < 10; ++k) {

//                 var pow = (Math.pow(i,3) + 
//                 Math.pow(j, 3));
//                 var plus = (i*100 + j*10 + k);

//                 if (pow == plus) {
//                     console.log(pow);
//                 }
//             }
//         }
//     }
// }

function isArmstrongNumber(num) {
    // convert the number to a string to get the number of digits
    const numStr = num.toString();
    const numDigits = numStr.length();

    // calculate the sum of each digits raised to the power of the number of digits
    let sum = 0;
    for (let i = 0; i < numDigits; i++) {
        const digit = parseInt(numStr[i]);
        sum += Math.pow(digit, numDigits);
    }

    // return true if the sum is equal to the original number, false otherwise
    return sum === num;
}

// example usage
console.log(isArmstrongNumber(153)) // true
console.log(isArmstrongNumber(370)) // true
console.log(isArmstrongNumber(9474)) // true
console.log(isArmstrongNumber(9475)) // false