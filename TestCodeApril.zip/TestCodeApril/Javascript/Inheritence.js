class Product
{
    constructor(id,name,price)
    {
        this.id=id;
        this.name=name;
        this.price=price;
    }
}



class Accounts extends Product
{
    constructor(id,name,price,discount)
    {
        super(); this.discount=discount;
    }

    receipt() { this.discount = this.price*this.discount/100; }

    report() {
        console.log("Product Id: " + this.id);
        console.log("Product Name: " + this.name);
        console.log("Product Price: " + this.price);
        console.log("Discount: " + this.discount);
    }
}

var obj = new Accounts(101,"John",5000,20);
obj.receipt();
obj.report();