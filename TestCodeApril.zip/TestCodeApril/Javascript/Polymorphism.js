class Pet
{
    display()
    {
        console.log("parent class is called");
    }
}

class Dog extends Pet
{
    display()
    {
        console.log("Dog class is callled");
    }
}

var obj = new Dog();
obj.display();