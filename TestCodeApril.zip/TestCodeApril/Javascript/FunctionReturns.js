function calc() {
    return a*b;
}

let res = calc(87, 34);

console.log(res);

console.log(calc(87, 34));
