const readline = require('readline');

const r1 = readline.createInterface({
    input:process.stdin,
    output:process.stdout
});

do {
    i = 0;
    // prompt user
    r1.question("Please enter your name: ", function(name) {
        r1.question("Please enter your hourly rate: "), function(hourlyRate) {
            r1.question("Please enter the number of hours worked: ", function(hoursWorked)) {

                // parse input as numbers
                hourlyRate = Number(hourlyRate);
                hoursWorked = Number(hoursWorked);

                // calculate gross pay
                const grossPay = hourlyRate * hoursWorked;

                // calculate deductions
                const taxRate = 0.1;
                const taxAmount = grossPay * taxRate;
                const netPay = grossPay - taxAmount;

                // generate payslip
                const payslip = `
                    Name: ${name}
                    Hours Worked: ${hoursWorked}
                    Hourly Rate: ${hourlyRate.toFixed(2)}
                    Gross Pay: ${grossPay.toFixed(2)}
                    Tax: ${taxAmount.toFixed(2)}
                    Net Pay: ${netPay.toFixed(2)}
                `
                ;

                // display payslip
                console.log(payslip);

                // close readline interface
                r1.close();
            }
        }
    });
}