const emp = new Map();

emp.set("name", "Sachin");
emp.set("age", 35);
emp.set("Country", "USA");

console.log(emp.size);

console.log(emp.get('name'));
console.log(emp.get('Country'));

for(let[key, value] of emp) {
    console.log(key + ": " + value);
}