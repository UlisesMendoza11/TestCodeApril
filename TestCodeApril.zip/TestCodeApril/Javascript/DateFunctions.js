const now = new Date();
console.log(now);
console.log(now.getDate());
console.log(now.getMonth());
console.log(now.getFullYear());
console.log(now.getHours());
console.log(now.getMinutes());
console.log(now.getSeconds());

const birthday = new Date('May 26, 1993');
console.log(birthday);
console.log(birthday.toLocaleDateString());
console.log(birthday.toLocaleString());

birthday.setDate(31);
console.log(birthday);
birthday.setMonth(6);
console.log(birthday);
birthday.setFullYear(1994);
console.log(birthday);